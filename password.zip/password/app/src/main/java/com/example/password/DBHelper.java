package com.example.password;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.CryptoPrimitive;
public class DBHelper extends SQLiteOpenHelper
{
    public static final String DBNAME="Loginnew2.db";

    public DBHelper(Context context) {
        super(context,"Loginnew2.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB)
    {

        MyDB.execSQL("create Table users(username TEXT,password TEXT,account TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1)
    {
        MyDB.execSQL("drop Table if exists users");
    }
    /*
    public Boolean insertData(String username,String password,String account)
    {
        SQLiteDatabase MyDB=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("username",username);
        contentValues.put("password",password);
        contentValues.put("account",account);
        long result=MyDB.insert("users",null,contentValues);
        if(result==-1) return false;
        else
            return true;
    }
     */
    public Boolean insertData(String username,String password,String account)
    {
        SQLiteDatabase MyDB=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("username",username);
        contentValues.put("password",password);
        contentValues.put("account",account);
        long result=MyDB.insert("users",null,contentValues);
        if(result==-1) return false;
        else
            return true;
    }

    public Boolean checkusername(String username,String account)
    {
        SQLiteDatabase MyDB=this.getWritableDatabase();
        Cursor cursor=MyDB.rawQuery("select * from users where username=? and account=?",new String[] {username});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public Boolean checkusernamepassword(String username)
    {
        SQLiteDatabase MyDB=this.getWritableDatabase();
        Cursor cursor=MyDB.rawQuery("select * from users where username=?",new String[] {username});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public Cursor getdata_gmail()
    {
        SQLiteDatabase MyDB=this.getWritableDatabase();
        Cursor cursor=MyDB.rawQuery("Select * from users where account='gmail'",null);
        return cursor;
    }
    public Cursor getdata_instagram()
    {
        SQLiteDatabase MyDB=this.getWritableDatabase();
        Cursor cursor=MyDB.rawQuery("Select * from users where account='insta'",null);
        return cursor;
    }
    public Cursor getdata_facebook()
    {
        SQLiteDatabase MyDB=this.getWritableDatabase();
        Cursor cursor=MyDB.rawQuery("Select * from users where account='facebook'",null);
        return cursor;
    }

}
