package com.example.password;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button insta,face,gmail;
    DBHelper DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        insta=(Button) findViewById(R.id.insta);
        face=(Button) findViewById(R.id.face);
        gmail=(Button)findViewById(R.id.gmail);
        DB=new DBHelper(this);

        insta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),insta_Activity.class);
                startActivity(intent);
            }
        });


        face.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),face_Activity.class);
                startActivity(intent);
            }
        });


            gmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),gmail_Activity.class);
                startActivity(intent);

            }
        });


    }
}