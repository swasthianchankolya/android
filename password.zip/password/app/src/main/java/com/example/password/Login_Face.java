package com.example.password;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login_Face extends AppCompatActivity {

    EditText username;
    Button btnlogin;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_face);
        btnlogin=(Button) findViewById(R.id.btnsignin1);
        // t=(TextView)findViewById(R.id.tview);
        DB=new DBHelper(this);
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Cursor res=DB.getdata_facebook();
                if(res.getCount()==0)
                {
                    Toast.makeText(Login_Face.this,"no data",Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while(res.moveToNext())
                {
                    buffer.append("username:"+res.getString(0)+"\n");
                    buffer.append("password:"+res.getString(1)+"\n");
                    buffer.append("account:"+res.getString(2)+"\n\n");
                }
                AlertDialog.Builder builder=new AlertDialog.Builder(Login_Face.this);
                builder.setCancelable(true);
                builder.setTitle("facebook entries");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });
    }
}