package com.example.password;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.scottyab.aescrypt.AESCrypt;

import java.security.GeneralSecurityException;

public class gmail_Activity extends AppCompatActivity {
    EditText username,password,account;
    Button signup,signin,gmail;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gmail);

        username=(EditText) findViewById(R.id.username);
        password=(EditText) findViewById(R.id.password);
        account=(EditText)findViewById(R.id.account);


        signup=(Button) findViewById(R.id.btnsignup);
        signin=(Button) findViewById(R.id.btnsignin);
        DB=new DBHelper(this);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user=username.getText().toString();
                String pass=password.getText().toString();
                String acc=account.getText().toString();

                String key="password";
                String finalpass="";
                try
                {
                    String newpass= AESCrypt.encrypt(key,pass);
                    finalpass=newpass;
                } catch (GeneralSecurityException e)
                {
                    e.printStackTrace();
                }


                if(user.equals("")||pass.equals("")||acc.equals(""))
                    Toast.makeText(gmail_Activity.this,"please enter all the fields",Toast.LENGTH_SHORT).show();
                else
                {
                    if(user!="")
                    {
                        Boolean checkuser=DB.checkusername(user,acc);
                        if(checkuser==false)
                        {
                            Boolean insert=DB.insertData(user,finalpass,acc);
                            if(insert==true)
                            {
                                Toast.makeText(gmail_Activity.this,"registered succesfully",Toast.LENGTH_SHORT).show();
                                Intent intent=new Intent(getApplicationContext(),Home_Activity.class);
                                startActivity(intent);
                            }
                            else
                            {
                                Toast.makeText(gmail_Activity.this,"registration falied",Toast.LENGTH_SHORT).show();
                            }
                        }
                        else
                        {
                            Toast.makeText(gmail_Activity.this,"user already exist",Toast.LENGTH_SHORT).show();
                        }
                    }
                    else
                    {
                        Toast.makeText(gmail_Activity.this,"cant be blank",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(intent);

            }
        });


    }
}