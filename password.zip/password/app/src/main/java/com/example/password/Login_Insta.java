package com.example.password;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.scottyab.aescrypt.AESCrypt;

import java.security.GeneralSecurityException;

public class Login_Insta extends AppCompatActivity {

    EditText username;
    Button btnlogin;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_insta);
        btnlogin=(Button) findViewById(R.id.btnsignin1);
        // t=(TextView)findViewById(R.id.tview);
        DB=new DBHelper(this);
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Cursor res=DB.getdata_instagram();
                if(res.getCount()==0)
                {
                    Toast.makeText(Login_Insta.this,"no data",Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                String key="password";
                    while (res.moveToNext())
                    {
                        String username=res.getString(0);
                        String password="";
                        try {
                            password=AESCrypt.decrypt(key,res.getString(1));
                            }
                        catch (GeneralSecurityException e)
                        {
                            e.printStackTrace();
                        }
                        String type=res.getString(2);
                        buffer.append("username:" +username+ "\n");
                        buffer.append("password:" +password+ "\n");
                        buffer.append("account:" +type+ "\n\n");
                    }
                    AlertDialog.Builder builder = new AlertDialog.Builder(Login_Insta.this);
                    builder.setCancelable(true);
                    builder.setTitle("instagram entires");
                    builder.setMessage(buffer.toString());
                    builder.show();
            }
        });
    }
}