package com.example.menu_screen;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void homelayoutButton(View view)
    {
        setContentView(R.layout.secondlayout);
    }
    public void secondlayoutButton(View view) {
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuinflater = getMenuInflater();
        menuinflater.inflate(R.menu.mymenu,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {


        switch(item.getItemId())
        {
            case R.id.home:
                setContentView(R.layout.activity_main);
                break;
            case R.id.secondlayout:
                setContentView(R.layout.secondlayout);
                break;
            case R.id.exit:
                finish();

        }
        return super.onOptionsItemSelected(item);
    }
}